/*David Wilson dwils036@ucr.edu
 * Partner: Hector Soto Jr
 *Lab Section: 023
 * Assignment: Lab 5 Exercise 1
 *Fuel Censor (No seatbelt)
 *
 *I acknowledge all content contained herein, excluding template or example code, 
 *is my own original work
 */ 
#include <avr/io.h>

int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs

	unsigned char fuel_1=0x00; // fuel level 1&2 PC 5     (0x10) (fuel light on) 
	unsigned char fuel_2=0x00; // fuel level 3&4 PC 4&5   (0x30) (fuel light on)
	unsigned char fuel_3=0x00; // fuel level 5&6 PC 3-5   (0x38) 
	unsigned char fuel_4=0x00; // fuel level 7-9 PC 2-5   (0x3C) 
	unsigned char fuel_5=0x00; // fuel level 10-12 PC 1-5 (0x3E)
	unsigned char fuel_6=0x00; // fuel level 12-15 PC 0-5 (0x3F)
	unsigned char totalAvalGas = 0x00;


	while (1)
	{
		totalAvalGas=~PINA&0x0F;

	
		if(totalAvalGas<3&&totalAvalGas>-1){
			fuel_1=0x20;
			PORTB=fuel_1|0x40; //|0x80 bit masking to show low fuel
		}
		
		
		if(totalAvalGas<5&&totalAvalGas>2){
			fuel_2=0x30;
			PORTB=fuel_2|0x40; //|0x80 bit masking to show low fuel
		}
		
		
		if(totalAvalGas<7&&totalAvalGas>4){
			fuel_3=0x38;
			PORTB=fuel_3;
		}
		
		
		if(totalAvalGas<10&&totalAvalGas>6){
			fuel_4=0x3C;
			PORTB=fuel_4;
		}
		
		if (totalAvalGas<13&&totalAvalGas>9){
			fuel_5=0x3E;
			PORTB = fuel_5;
		}
		
		if (totalAvalGas<16&&totalAvalGas>11){
			fuel_6=0x3F;
			PORTB=fuel_6;
		}
		
		
		
	}	
	
}
