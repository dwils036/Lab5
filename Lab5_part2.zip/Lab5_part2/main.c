/*David Wilson (862134618) dwils036@ucr.edu
 * Partner: Hector Soto Jr
 * Lab Section: 023
 * Assignment: Lab 5 Exercise 2
 * Increment/Decrement Calculator
 * I acknowledge all content contained herein, excluding template or example
 * code, is my own original work.
 */ 

#include <avr/io.h>

enum simpleCalculator {init, incre, decre, reset, wait0, waitincre, waitdecre, waitreset} state;
unsigned char button0 = 0x00;
unsigned char button1 = 0x00;

void calculate()
{
	//transitions
	switch(state)
	{
		case init:
		state = wait0;
		break;
		
		case wait0:
		if(!button0 && button1)
		state = incre;
		if(button0 && !button1)
		state = decre;
		if(button0 && button1)
		state = reset;
		if(!button0 && !button1)
		state = wait0;
		break;
		
		case incre:
		state = waitincre;
		break;
		
		case waitincre:
		if(!button0 && button1)
		state = waitincre;
		else
		state = wait0;
		break;
		
		case decre:
		state = waitdecre;
		break;
		
		case waitdecre:
		if(button0 && !button1)
		state = waitdecre;
		else
		state = wait0;
		break;
		
		case reset:
		state = waitreset;
		break;
		
		case waitreset:
		if(button0 && button1)
		state = waitreset;
		else
		state = wait0;
		break;
		
		default:
		state = init;
		break;
	}
	
	//actions
	switch(state)
	{
		case init:
		break;
		
		case wait0:
		break;
		
		case incre:
		if(PORTB != 0x09)
		PORTB = PORTB + 0x01;
		break;
		
		case waitincre:
		break;
		
		case decre:
		if(PORTB != 0x00)
		PORTB = PORTB - 0x01;
		break;
		
		case waitdecre:
		break;
		
		case reset:
		PORTB = 0x00;
		break;
		
		case waitreset:
		break;
		
		default:
		break;
	}
}

int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; //initialization for input
	DDRB = 0xFF; PORTB = 0x00; //initialization for output
	
	state = init;
	PORTB = 0x07; //initial starting value for PORTB
	
	
	while (1)
	{
		button0 = ~PINA & 0x01;
		button1 = ~PINA & 0x02;
	
		calculate();
	}
	return 0;
}
